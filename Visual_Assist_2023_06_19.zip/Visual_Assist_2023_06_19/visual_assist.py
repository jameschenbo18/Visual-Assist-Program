import sys
import csv
import math
#import numpy as np
#import itertools as it
#import scipy.stats as st
import matplotlib.pyplot as plt
from matplotlib.backend_bases import MouseButton

###############################################################################
#Global Variables:
#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
config=[]
#analysis mode: initial peak comes from ncacx or ncocx
mode='3D_NCACX'#'3D_NCOCX', '2D_NCACX', '2D_NCOCX', '2D_CC'
antimode='3D_NCOCX'
    #[original directory name, spectrum type, column format, peaklist]
verbose=True
ncacx_peaklist = []#ncacx_peaklist: straight from the csv file
listA = []#listA: initial list of peaks that input peak comes from
ncocx_peaklist = []#ncocx_peaklist: straight from the csv file
listB = []#listB: second list of peaks to compare in parallel to first list
#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#spectral width variables:
#delta omega N = [delta, downfield, upfield]
dwN = [140-90, 140,90]
#delta omega CA
dwCA = [73-43, 73,43]
#delta omega CO
dwCO = [210-160, 210,160]
#delta omega CX
dwCX = [210-0, 210,0]
#delta omega used for spectrum A
dwC_A = [73-43, 73,43]
#delta omega used for spectrum B
dwC_B = [210-160, 210,160]
#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#A_M0: first magnitude array
A_M0 = [ [n, pow(n*1.0/dwCX[0],2), n] for n in range(dwCX[0]) ]
#B_M0: second magnitude array
B_M0 = [ [n, 1.0-pow(n*1.0/dwCX[0],2), n, 0.0] for n in range(dwCX[0]) ]
#ncacx and ncocx carbon & nitrogen tolerances
dC_nca, dN_nca, dC_nco, dN_nco = 0.3, 0.5, 0.3, 0.5
#graphA and graphB carbon & nitrogen tolerances
dCa, dNa, dCb, dNb = 0.3, 0.5, 0.3, 0.5
#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#initial point
#p0 = [0.0,0.0,0.0]
#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#-            SAMPLE PEAKS            =
#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#w1, w2, w3 = 113.589, 53.09, 39.877
#w1, w2, w3 = 124.683, 61.489, 33.686
#w1, w2, w3 = 122.142, 55.463, 29.932
#w1, w2, w3 = 122.599, 173.949, 54.354
#w1, w2, w3 = 128.9, 177.0, 50.4
#w1, w2, w3 = 119.8, 173.1, 54.58
#w1, w2, w3 = 130.824, 45.518, 45.476
#w1, w2, w3 = 114.3, 55.7, 33.6#M44 Cb
#w1, w2, w3 = 112.5, 60.43, 63.71#S45 Cb
#w1, w2, w3 = 113, 57, 63.7
w1, w2, w3 = 120.2, 58.3, 42.4
p0 = [w1, w2, w3]
#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
magYheightGrad=True
#max,min color for listA: green, grey
Acolor_max, Acolor_min = (0.0,1.0,0.0), (0.5,0.5,0.5)
#max,min color for listB: red, grey
Bcolor_max, Bcolor_min = (1.0,0.0,0.0), (0.5,0.5,0.5)
###############################################################################
def run_text_gui():
    print ("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=")
    print ("     NCACX/NCOCX VISUAL ASSIGNMENT ASSISTANCE      ")
    print ("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=")
###############################################################################
# Load up peaklist files
def load_peaklists():
    global ncacx_peaklist, ncocx_peaklist
    loop=True#check to see if both peaklist csv files are ready & read them
    while loop:#ncacx.csv
        try:
            with open('ncacx.csv', 'r') as readFile:
                reader = csv.reader(readFile)
                ncacxstr = list(reader)
            loop=False
        except:
            inp=input("  File error. Make sure 'ncacx.csv' is in the same directory\n  as this program.\n  Press Enter to retry...")
            if inp=='q':
                save_configuration()
                sys.exit()
    #place it in ncacx_peaklist
    #['ncacx.csv', '3D_NCACX', ['CA','N','CX'], [
    loop=True
    while loop:#ncacx.csv
        try:
            ncacx_peaklist = [ ncacxstr[0][0], ncacxstr[1][0], ncacxstr[2][0:3], [ [ float(n) for n in p[0:5] ] for p in ncacxstr[4:] ] ]           
            loop=False
        except:
            inp=input("  File error. 'ncacx.csv' is formatted incorrectly.\n  Press Enter to retry...")
            if inp=='q':
                save_configuration()
                sys.exit()
            #loop=False
    loop=True
    while loop:#ncocx.csv
        try:
            with open('ncocx.csv', 'r') as readFile:
                reader = csv.reader(readFile)
                ncocxstr = list(reader)
            loop=False
        except:
            inp=input ("  File error. Make sure 'ncocx.csv' is in the same\n  directory as this program.\n  Press Enter to retry...")
            if inp=='q':
                save_configuration()
                sys.exit()
    #place it in ncocx_peaklist
    loop=True
    while loop:#ncocx.csv
        try:
            ncocx_peaklist = [ ncocxstr[0][0], ncocxstr[1][0], ncocxstr[2][0:3], [ [ float(n) for n in p[0:5] ] for p in ncocxstr[4:] ] ]
            loop=False
        except:
            inp=input("  File error. 'ncocx.csv' is formatted incorrectly.\n  Press Enter to retry...")
            if inp=='q':
                save_configuration()
                sys.exit()
            #loop=False
    print("")
###############################################################################
def run_options_menu():
    loop=True
    while loop:
        print("")
        print("Pick from one of the following options, or press enter to graph:")
        print("  t: Tolerance | c: Comparison | p: Peak | e: Excluded | d: Display | q: Quit")
        option = input("  ")
        if option=='':#perform the regular graphing function
            graph()
            display_graph()
        elif option=='t':#Tolerance: adjust tolerance values
            run_option_tolerance()
        elif option=='c':#Spectra: select which spectra to compare to each other (listA vs listB)
            run_option_comparison()
        elif option=='p':#Peak: Graph A Peak Start Location
            run_option_peak()
        elif option=='e':#Exclusion: Peak Exclusion List
            run_option_exclusion()
        elif option=='d':#Format: Peak Height / Alignment by Color / Y-Axis
            run_option_display()
        elif option=='q':#Quit: end program
            loop=False
        elif option=='s':#Special: run special
            modal = input("Special mode:")
            print("modality:", modal)
            run_option_special(int(modal))
        else:
            print("  Please select one of the provided options.")
        #elif option=='exit':
        #    loop=False
###############################################################################
    ###########################################################
    ##                      Tolerance
    ###########################################################
def run_option_tolerance():
    global dC_nca, dN_nca, dC_nco, dN_nco
    print("")
    print("Tolerance Value Adjustment:")
    print("  Enter new tolerance values in ppm or press enter to skip:")
    loop=True#ask what NCACX carbon tolerance to use (default 0.3ppm)
    while loop:
        try:
            inp=input("    NCACX carbon tolerance value? (current: "+str(dC_nca)+"): ")
            if not(inp==""): dC_nca = float(inp)
            loop=False
        except ValueError:
            print("        Please input a numerical value in decimal form.")
        except:
            print ("        Error.")
    loop=True#ask what NCACX nitrogen tolerance to use (default 0.5ppm)
    while loop:
        try:
            inp=input("    NCACX nitrogen tolerance value? (current: "+str(dN_nca)+"): ")
            if not(inp==""): dN_nca = float(inp)
            loop=False
        except ValueError:
            print("        Please input a numerical value in decimal form.")
        except:
            print ("        Error.")
    loop=True#ask what NCOCX carbon tolerance to use (default 0.3ppm)
    while loop:
        try:
            inp=input("    NCOCX carbon tolerance value? (current: "+str(dC_nco)+"): ")
            if not(inp==""): dC_nco = float(inp)
            loop=False
        except ValueError:
            print("        Please input a numerical value in decimal form.")
        except:
            print ("        Error.")
    loop=True#ask what NCOCX nitrogen tolerance to use (default 0.5ppm)
    while loop:
        try:
            inp=input("    NCOCX nitrogen tolerance value? (current: "+str(dN_nco)+"): ")
            if not(inp==""): dN_nco = float(inp)
            loop=False
        except ValueError:
            print("        Please input a numerical value in decimal form.")
        except:
            print ("        Error.")
###############################################################################
    ###########################################################
    ##                  Spectra Comparison
    ###########################################################
def run_option_comparison():
    global mode, antimode
    #ask which spectrum type to start with and use for spectrum A:
    print("")
    print("Spectrum Comparison Settings:")
    loop=True
    while loop:
        try:
            print("    Which spectrum type do you want to input your initial peak from?")
            inp=input("        1 = 3D_NCACX, 2 = 3D_NCOCX: (current: "+mode+")")#, 3 = 2D_NCACX, 4 = 2D_NCOCX, 5 = 2D_CC: ")
            if not(inp==""):
                m = int(inp)
                if m<=2 and m>0:#when more spectra added, change 'm<=2' to appropriate size
                    modes = [ '3D_NCACX', '3D_NCOCX' ]#, '2D_NCACX', '2D_NCOCX', '2D_CC']
                    mode = modes[m-1]
                    loop=False
                else:
                    print("        Please enter one of the choices available.")
            else: loop=False
        except ValueError:
            print("        Please enter a numerical choice.")
        except:
            print ("        Error.")
    #ask which spectrum type to use for spectrum B:
    loop=True
    while loop:
        try:
            print("    Which spectrum type do you want to compare to?")
            inp=input("        1 = 3D_NCACX, 2 = 3D_NCOCX: (current: "+antimode+")")#, 3 = 2D_NCACX, 4 = 2D_NCOCX, 5 = 2D_CC: ")
            if not(inp==""):
                m = int(inp)
                if m<=2 and m>0:#when more spectra added, change 'm<=2' to appropriate size
                    modes = [ '3D_NCACX', '3D_NCOCX' ]#, '2D_NCACX', '2D_NCOCX', '2D_CC']
                    antimode = modes[m-1]
                    loop=False
                else:
                    print("        Please enter one of the choices available.")
            else: loop=False
        except ValueError:
            print("        Please enter a numerical choice.")
        except:
            print ("        Error.")
    set_listAB()
###############################################################################
def set_listAB():
    global mode, antimode, listA, listB, dwCA, dwCO, dwC_A, dwC_B, dC_nca, dN_nca, dC_nco, dN_nco, dCa, dNa, dCb, dNb
    ###Set up List A to be associated with the chosen starting spectra
    if mode=='3D_NCACX':
        dwC_A, dCa, dNa = dwCA, dC_nca, dN_nca
        listA = [ [i]+ncacx_peaklist[3][i] for i in range(len(ncacx_peaklist[3]))]
    elif mode=='3D_NCOCX':
        dwC_A, dCa, dNa = dwCO, dC_nco, dN_nco
        listA = [ [i]+ncocx_peaklist[3][i] for i in range(len(ncocx_peaklist[3]))]
    ## and listB to be the other one
    if antimode=='3D_NCACX':
        dwC_B, dCb, dNb = dwCA, dC_nca, dN_nca
        listB = [ [i]+ncacx_peaklist[3][i] for i in range(len(ncacx_peaklist[3]))]
    elif antimode=='3D_NCOCX':
        dwC_B, dCb, dNb = dwCO, dC_nco, dN_nco
        listB = [ [i]+ncocx_peaklist[3][i] for i in range(len(ncocx_peaklist[3]))]
###############################################################################
    ###########################################################
    ##                      Peak
    ###########################################################
def run_option_peak():
    #Note: Going to have to add some conditional loop once more spectrum types are added
    global p0, w1, w2, w3
    print("")
    print("Initial Peak Input:")
    #ask what peak to start with:
    print("    For which location in", mode, "would you like to find a set of aligned \n"+
          "    corresponding peaks to? ("+mode[3]+", "+mode[4:6]+", "+mode[6:8]+")")
    loop=True#  #w1
    while loop:
        try:
            inp=input("        "+mode[3]+" (in ppm): ")
            if not(inp==""): w1 = float(inp)#take out the conditional part later
            loop=False
        except ValueError:
            print("        Please input a numerical value in decimal form.")
        except:
            print ("        Error.")
    loop=True#  #w2
    while loop:
        try:
            inp=input("        "+mode[4:6]+" (in ppm): ")
            if not(inp==""): w2 = float(inp)#take out the conditional part later
            loop=False
        except ValueError:
            print("        Please input a numerical value in decimal form.")
        except:
            print ("        Error.")
    if mode[0]=='3':
        loop=True#  #w3
        while loop:
            try:
                inp=input("        "+mode[6:8]+" (in ppm): ")
                if not(inp==""): w3 = float(inp)#take out the conditional part later
                loop=False
            except ValueError:
                print("        Please input a numerical value in decimal form.")
            except:
                print ("        Error.")
    print("")
    p0 = [w1, w2, w3]
    print ("  p0 =",p0)
###############################################################################
    ###########################################################
    ##                      Exclusion
    ###########################################################
def run_option_exclusion():
    global ncacx_peaklist, ncocx_peaklist
    print("")
    print("Peak Exclusion List:")
    load_peaklists()
    set_listAB()
    print("    List Updated. Display excluded list? (y=yes)")
    inp=input("")
    if inp=='y':
        print("    The following peaks have been marked for exclusion from consideration:")
        print("        NCACX:")
        for p in range(len(ncacx_peaklist[3])):
            if ncacx_peaklist[3][p][4]==0: print("            Peak "+str(p)+": "+str(ncacx_peaklist[3][p][0:4]))
        print("        NCOCX:")
        for p in range(len(ncocx_peaklist[3])):
            if ncocx_peaklist[3][p][4]==0: print("            Peak "+str(p)+": "+str(ncocx_peaklist[3][p][0:4]))
        input("")
###############################################################################
    ###########################################################
    ##                         Display
    ###########################################################
#                                                
# Change display settings, like Peak Height/Alignment by Color/Y-Axis options and color gradients
def run_option_display():
    global magYheightGrad, Acolor_max, Acolor_min, Bcolor_max, Bcolor_min, Acolors, Bcolors
    print("")
    print("Graph Display Settings:")# Peak Height / Alignment by Color / Y-Axis")
    if magYheightGrad:
        print("   Peak Alignment Magnitude -> Y-Axis | Data Height -> Color Gradient")
    else:
        print("   Data Height -> Color Gradient |  Peak Alignment Magnitude -> Y-Axis")
    invert=input("      Invert? (y=yes)")
    if invert=='y':
        magYheightGrad = not(magYheightGrad)
    gradient_change=input("  Change color gradients? (y=yes)")
    if gradient_change=='y':
        loop=True
        while loop:
            loop1, loop2 = True, True
            print("      1 = Graph A Max Color, 2 = Graph A Min Color, 3 = Graph B Max Color, 4 = Graph B Min Color")
            grad = input("          ")
            if len(grad)==0: loop, loop1, loop2 = False, False, False
            while loop1:
                try:
                    grad=int(grad)
                    color=[Acolor_max, Acolor_min, Bcolor_max, Bcolor_min][grad-1]
                    print( "          RGB =", color )
                    lcolor=list(color)
                    loop1=False
                except:
                    print("          Enter one of the options above as a number.")
                    grad = input("          ")
            if loop2:
                for c in range(3):
                    loop2=True
                    while loop2:
                        try:
                            cval=input("              New "+str(['R','G','B'][c])+": ")
                            if not(len(cval)==0): lcolor[c]=float(cval)
                            loop2=False
                        except:
                            print("          Numerical values only.")
                color = tuple(lcolor)
                if grad==1:Acolor_max=color
                elif grad==2:Acolor_min=color
                elif grad==3:Bcolor_max=color
                elif grad==4:Bcolor_min=color
                print( "          RGB =", color )
        Acolors = generate_gradient(Acolor_max, Acolor_min)
        Bcolors = generate_gradient(Bcolor_max, Bcolor_min)

###############################################################################
# Load up config files from config.csv
def load_configuration():
    global config, mode, antimode, dC_nca, dN_nca, dC_nco, dN_nco, w1, w2, w3, p0
    global magYheightGrad, Acolor_max, Acolor_min, Bcolor_max, Bcolor_min, Acolors, Bcolors
    try:
        with open('config.csv', 'r') as readFile:
            reader = csv.reader(readFile)
            config = list(reader)
    except:
        print("No config file present.")
    for c in range(12):
        if config[c][0]=='mode': mode=config[c][1]
        elif config[c][0]=='antimode': antimode=config[c][1]
        elif config[c][0]=='dC_nca': dC_nca=float(config[c][1])
        elif config[c][0]=='dN_nca': dN_nca=float(config[c][1])
        elif config[c][0]=='dC_nco': dC_nco=float(config[c][1])
        elif config[c][0]=='dN_nco': dN_nco=float(config[c][1])
        elif config[c][0]=='magYheightGrad': magYheightGrad = bool(int(config[c][1]))
        elif config[c][0]=='p0': p0 = (w1, w2, w3) = (float(config[c][1]), float(config[c][2]), float(config[c][3]))
        elif config[c][0]=='Acolor_max': Acolor_max = (float(config[c][1]), float(config[c][2]), float(config[c][3]))
        elif config[c][0]=='Acolor_min': Acolor_min = (float(config[c][1]), float(config[c][2]), float(config[c][3]))
        elif config[c][0]=='Bcolor_max': Bcolor_max = (float(config[c][1]), float(config[c][2]), float(config[c][3]))
        elif config[c][0]=='Bcolor_min': Bcolor_min = (float(config[c][1]), float(config[c][2]), float(config[c][3]))
    Acolors = generate_gradient(Acolor_max, Acolor_min)
    Bcolors = generate_gradient(Bcolor_max, Bcolor_min)

###############################################################################
# Record and save Configuration to config.csv
def save_configuration():
    try:
        with open('config.csv', 'w', newline='') as writeFile:
            writer = csv.writer(writeFile)
            writer.writerows(
                [
                    ['mode', mode],
                    ['antimode', antimode],
                    ['dC_nca', dC_nca],
                    ['dN_nca', dN_nca],
                    ['dC_nco', dC_nco],
                    ['dN_nco', dN_nco],
                    ['p0']+list(p0),
                    ['magYheightGrad', int(magYheightGrad)],
                    ['Acolor_max']+list(Acolor_max),
                    ['Acolor_min']+list(Acolor_min),
                    ['Bcolor_max']+list(Bcolor_max),
                    ['Bcolor_min']+list(Bcolor_min)
                    ]
                )
    except:
        print("No config file present.")
###############################################################################

peaks_highlighted_A =[]
peaks_highlighted_B =[]
all_displayed = False
B_displayed = 0
bplots = []
aplots = []
delay_timer_tick=0
cp=0

def on_move(event):
    # get the x and y pixel coords
    xd, yd = event.xdata, event.ydata
    #print(xd, yd)
    if event.inaxes:
        ax = event.inaxes  # the axes instance
        xb, yb = ax.bbox.width, ax.bbox.height
        axtitle = ax.get_title()
        global dwCX, cp

        #global draw_circle
        #ax.add_artist(draw_circle)
        
        if axtitle[13]==mode[5]:#listA
            global A_M0, listA, graphA_min, yArange, highlightA, aplots
            xyr = yArange*yb*dwCX[0]/xb # (float) ratio of horizontal axis units to vertical axis units, w/respect to actual pixel dimensions
            cp = closest(xd, yd, aplots, graphA_min, xyr)#index of closest peak to mouse
            #lacp, cp = closest(xd, yd, A_M0, xyr)#index of closest peak to mouse
            ax.set_xlabel("Peak "+str(listA[A_M0[cp][0]][0])+": "+str(listA[A_M0[cp][0]][1:5]))
            highlightA[0].set_xdata(aplots[cp][0].get_xdata())#([A_M0[amcp][2], A_M0[amcp][2]])
            highlightA[0].set_ydata(aplots[cp][0].get_ydata())#([graphA_min, A_M0[amcp][1]])
            highlightA[0].set_visible(True)
        elif axtitle[13]==antimode[5]:#listB
            global B_M0, listB, graphB_min2, yBrange, highlightB, bplots
            xyr = yBrange*yb*dwCX[0]/xb # (float) ratio of horizontal axis units to vertical axis units, w/respect to actual pixel dimensions
            if not all_displayed:
                cp = closest(xd, yd, bplots[B_displayed], graphB_min2, xyr)#index of closest peak to mouse
                #lbcp, bmcp = closest(xd, yd, B_M0[B_displayed][1], xyr)#index of closest peak to mouse
                ax.set_xlabel("Peak "+str(listB[B_M0[B_displayed][1][cp][0]][0])+": "+str(listB[B_M0[B_displayed][1][cp][0]][1:5]))
                highlightB[0].set_xdata(bplots[B_displayed][cp][0].get_xdata())#([B_M0[B_displayed][1][bmcp][2], B_M0[B_displayed][1][bmcp][2]])
                highlightB[0].set_ydata(bplots[B_displayed][cp][0].get_ydata())#([graphB_min2, B_M0[B_displayed][1][bmcp][1]])
                highlightB[0].set_visible(True)
        plt.draw()
    else:
        plt.draw()
        
def press(event):
    #print('press', event.key)
    sys.stdout.flush()
    global plots, bplots, B_displayed, all_displayed
    if event.key == ',':
        if not all_displayed:
            change_resonance(-1)
    elif event.key == '.':
        if not all_displayed:
            change_resonance(1)
    elif event.key == '/':
        if all_displayed:
            for b in bplots:
                for z in b: z[0].set_visible(False)
            for z in bplots[B_displayed]: z[0].set_visible(True)
            plots[1].set_title('Aligned '+antimode+' Peaks: Resonance '+str(B_displayed+1)+'/'+str(len(bplots)))
            all_displayed = False
        else:
            for b in bplots:
                for z in b: z[0].set_visible(True)
            plots[1].set_title('Aligned '+antimode+' Peaks: '+str(len(bplots))+' Resonances')
            all_displayed = True
        fig.canvas.draw()
    elif event.key == 'm':
        pass

def change_resonance(direction):
    global plots, bplots, B_displayed, antimode, highlightB
    for z in bplots[B_displayed]: z[0].set_visible(False)
    highlightB[0].set_visible(False)
    B_displayed+=direction
    if B_displayed<0: B_displayed=len(bplots)-1
    elif B_displayed>len(bplots)-1: B_displayed=0
    for z in bplots[B_displayed]: z[0].set_visible(True)
    plots[1].set_title('Aligned '+antimode+' Peaks: Resonance '+str(B_displayed+1)+'/'+str(len(bplots)))
    fig.canvas.draw()

def on_click(event):
    
    if event.button is MouseButton.LEFT:
        # get the x and y pixel coords
        xd, yd = event.xdata, event.ydata
        #print(xd, yd)
        if event.inaxes:
            global dwCX, cp
            ax = event.inaxes  # the axes instance
            xb, yb = ax.bbox.width, ax.bbox.height
            axtitle = ax.get_title()
            if axtitle[13]==mode[5]:#listA
                global A_M0, listA, graphA_min, yArange, highlightA, aplots, peaks_highlighted_A
                marker = plots[0].plot([100,100],[0,1],c='orange')
                marker[0].set_visible(False)
                marker[0].set_xdata(aplots[cp][0].get_xdata())
                marker[0].set_ydata(aplots[cp][0].get_ydata())
                marker[0].set_visible(True)
                peaks_highlighted_A.append([1*cp,marker])
                
            elif axtitle[13]==antimode[5]:#listB
                global B_M0, listB, graphB_min2, yBrange, highlightB, bplots, B_displayed, peaks_highlighted_B
                marker = plots[1].plot([50,50],[0,1],c='orange')
                marker[0].set_visible(False)
                marker[0].set_xdata(bplots[B_displayed][cp][0].get_xdata())
                marker[0].set_ydata(bplots[B_displayed][cp][0].get_ydata())
                marker[0].set_visible(True)
                peaks_highlighted_B.append([1*cp,marker])
        #plots[0].plot([1,5],[1,5])
        #plt.draw()
        pass
        #print('CLICK!')

def highlight_peak(peaklist, p, color):#peak list, peak index, matplotlib color value
    pass

def dehighlight_peak(peaklist, p):
    pass

def closest(xdata, ydata, peaklist, xyr):#xyr = x to y ratio of axis units
    cp = 0 #place holder for index of closest peak to mouse
    for m in range(len(peaklist)):
        if (((peaklist[cp][1]/2-ydata)*xyr)**2+(peaklist[cp][2]-xdata)**2)>(((peaklist[m][1]/2-ydata)*xyr)**2+(peaklist[m][2]-xdata)**2):
            cp = 0+m
    return peaklist[cp][0], cp

def closest(xdata, ydata, plotlist, ymin, xyr):#xyr = x to y ratio of axis units
    cp = 0 #place holder for index of closest peak to mouse
    for m in range(len(plotlist)):
        if ((((max(plotlist[cp][0].get_ydata())-ymin)/2-(ydata-ymin))*xyr)**2+(max(plotlist[cp][0].get_xdata())-xdata)**2)>(
            (((max(plotlist[m][0].get_ydata())-ymin)/2-(ydata-ymin))*xyr)**2+(max(plotlist[m][0].get_xdata())-xdata)**2):
            cp = 0+m
    return cp

def peaks_in_line(peaklist, p):#peak list, peak index
    return [ b[0] for b in peaklist if b[3]==p ]

def graph_point(splot, high_y, x, low_y, color):
    p = splot.plot([x,x],[low_y,high_y],c=color)#Returns: list of Line2D
    return p

#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= COLOR CODE =-=-=-=-=-=-=-=-=-=-=-=-=-=
color_steps = 30 #color steps: the number of color gradient increments
def generate_gradient(maxcolor, mincolor):
    global color_steps
    return [ [ mincolor[i]+(maxcolor[i]-mincolor[i])*n/color_steps for i in range(3) ] for n in range(color_steps+1) ]
def get_gradient_color(colors,val,val_max,val_min):
    return colors[int( color_steps*(val-val_min)/(val_max-val_min) )]
Acolors = generate_gradient(Acolor_max, Acolor_min)
Bcolors = generate_gradient(Bcolor_max, Bcolor_min)
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

###############################################################################
######################################### Main Graph Function #################
def graph():
    global p0, listA, listB, A_M0, B_M0, graphA_min, graphB_min2, yArange, yBrange
    global Acolor_max, Acolor_min, Bcolor_max, Bcolor_min, Acolors, Bcolors
    global plots, fig, aplots, bplots, magYheightGrad, verbose, all_displayed

    #set the lists A and B up appropriately
    set_listAB()
    if verbose: print("Graph Peak Alignment:")
    if verbose: print ("  p0 =",p0)

    #set up graphs
    fig, plots = plt.subplots(2,1)#3,1 for when middle stage graph is set on
    fig.subplots_adjust(hspace=5.0)
    fig.subplots_adjust(wspace=2.0)

    #set mouse action binding to graphs
    binding_id = plt.connect('motion_notify_event', on_move)
    plt.connect('button_press_event', on_click)
    fig.canvas.mpl_connect('key_press_event', press)

    #compute A_M0, the first magnitude array
    #A_M0 = list of [ listA_index, Magnitude_P0_alignment, listA_w3 ]
    A_M0 = [ [ lA[0],((dwN[0]-abs(lA[1]-p0[0]))**2+(dwC_A[0]-abs(lA[2]-p0[1]))**2)/(dwN[0]**2+dwC_A[0]**2), lA[3] ]
             for lA in listA if bool(lA[5]) and abs(lA[1]-p0[0])<=dNa and abs(lA[2]-p0[1]) <=dCa]
    magA_min = ((dwN[0]-dNa)**2+(dwC_A[0]-dCa)**2)/(dwN[0]**2+dwC_A[0]**2)
    
    #set up data height values for graph A and B
    dataHtsA = [ math.log(a[4],10) for a in listA ]
    dataHtsB = [ math.log(b[4],10) for b in listB ]
    Aval_max, Aval_min = max(dataHtsA), min(dataHtsA)
    Bval_max, Bval_min = max(dataHtsB), min(dataHtsB)

    #graph A_M0
    plots[0].set_title('Aligned '+mode+' Peaks')
    plots[0].set_xlabel("CX (ppm)")
    if magYheightGrad: plots[0].set_ylabel("Normalized Alignment\nMagnitude")
    else: plots[0].set_ylabel("log(Data Height)")
    plots[0].set_xlim(dwCX[1],dwCX[2])
    if magYheightGrad: graphA_min = magA_min
    else: graphA_min = Aval_min-1.0
    if magYheightGrad: yArange = 1.0 - magA_min
    else: yArange = Aval_max - (Aval_min-1.0)
    if magYheightGrad: plots[0].set_ylim(magA_min,1.0)
    else: plots[0].set_ylim(Aval_min-1.0,Aval_max)
    #graph_point(splot, high_y, x, low_y, color)
    #get_gradient_color(colors,val,val_max,val_min):
    if magYheightGrad: aplots = [ graph_point(plots[0], a[1], a[2], magA_min, get_gradient_color(Acolors,dataHtsA[a[0]],Aval_max,Aval_min)) for a in A_M0 ]
    else: aplots = [ graph_point(plots[0], dataHtsA[a[0]], a[2], Aval_min-1.0, get_gradient_color(Acolors,a[1],1.0,magA_min)) for a in A_M0 ]

    if verbose: print(" ", len(A_M0), mode, "peaks aligned with p0.")#graphed

    #make list P_A of ncocx peaks which match CA or CX-sidechain picked, with Kappa_1 value of A_M0 alignment for each
    P_A=[ ]
    for lB in listB:
        if bool(lB[5]):
            if abs(lB[3]-p0[1])<=dCb:
                P_A.append(lB[0:4]+[(dCb-abs(lB[3]-p0[1]))**2/dCb**2])
            elif abs(lB[3]-p0[2])<=dCb:
                P_A.append(lB[0:4]+[(dCb-abs(lB[3]-p0[2]))**2/dCb**2])
    #print(len(P_A), antimode, "peaks (list P_A) that can correspond to p0's direct and indirect carbon dimensions.")

    #make Array_Mag_C: magnitude list of peaks in NCOCX listB that match with peaks in P_A
    #A_MC = list of [ P_Alpha_index, list of [ listB_index, kappa1_of_P_A * Magnitude_P_A_alignment, listB_w3 ] ]
    A_MC = [ [ pA[0],
               [ [ lB[0],
                   pA[4]*(((dwN[0]-abs(pA[1]-lB[1]))**2+(dwC_B[0]-abs(pA[2]-lB[2]))**2)/(dwN[0]**2+dwC_B[0]**2)),
                   lB[3] ]
                 for lB in listB if bool(lB[5]) and abs(pA[1]-lB[1])<=dNb and abs(pA[2]-lB[2])<=dCb ] ]
             for pA in P_A ]
    #print(len(A_MC), antimode, "resonances with indirect dimension alignment with the peaks of P_A.")

    #finally, compute B_M0, the second magnitude array
        #B_M0: list of [ P_A_index, list of [ listB_peak_index, magnitude, w3 ] ]
        #magnitude = kappa2 * magnitude_M_Bi * magnitude_M_Ci
    B_M0 = []
    for m in range(len(A_MC)):
        B_M0.append([ A_MC[m][0],[] ])
        for j in range(len(A_MC[m][1])):
            t = [abs(A_M0[i][2]-A_MC[m][1][j][2]) for i in range(len(A_M0))]#
            if len(t)>0 and min(t)<=dCb:#if within dCb of any of A_M0
                B_M0[-1][1].append( [ A_MC[m][1][j][0], ((dCb-min(t))**2/dCb**2)*A_M0[t.index(min(t))][1]*A_MC[m][1][j][1], A_MC[m][1][j][2] ] )
    #remove resonances with 1 or 0 peaks:
    B_M0 = [ b for b in B_M0 if len(b[1])>0 ]
    #magB_min = ((dwC_A[0]-dCb)**2/dwC_A[0]**2) * magA_min * graphB_min
    magB_min = 0
    if verbose: print(" ", len(B_M0), antimode, "resonances aligned with the p0-aligned", mode, "resonance.")#graphed

    #graph B_M0
    plots[1].set_title('Aligned '+antimode+' Peaks')
    plots[1].set_xlabel("CX (ppm)")
    if magYheightGrad: plots[1].set_ylabel("Normalized Alignment\nMagnitude")
    else: plots[1].set_ylabel("log(Data Height)")
    plots[1].set_xlim(dwCX[1],dwCX[2])
    plots[1].set_ylim(0,1)
    #graphB_min2 = ((dwC_A[0]-dCb)**2/dwC_A[0]**2) * graphA_min * graphB_min
    if magYheightGrad: graphB_min2 = magB_min
    else: graphB_min2 = Bval_min-1.0
    if magYheightGrad: yBrange = 1.0 - magB_min
    else: yBrange = Bval_max - (Bval_min-1.0)
    if magYheightGrad: plots[1].set_ylim(magB_min,1.0)
    else: plots[1].set_ylim(Bval_min-1.0,Bval_max)
    
    #graph_point(splot, high_y, x, low_y, color)
    #get_gradient_color(colors,val,val_max,val_min)
    if magYheightGrad: bplots = [ [ graph_point(plots[1], z[1], z[2], magB_min, get_gradient_color(Bcolors,dataHtsB[z[0]],Bval_max,Bval_min))
                                    for z in b[1] ] for b in B_M0 ]
    else: bplots = [ [ graph_point(plots[1], dataHtsB[z[0]], z[2], Bval_min-1.0, get_gradient_color(Bcolors,z[1],1.0,magB_min))
                                    for z in b[1] ] for b in B_M0 ]

    global highlightA, highlightB
    #Set the peak highlight initial state
    highlightA = plots[0].plot([100,100],[0,1],c='orange')
    highlightA[0].set_visible(False)
    highlightB = plots[1].plot([50,50],[0,1],c='orange')
    highlightB[0].set_visible(False)
    
    #If there is anything plottable:
    if len(A_M0)>0 and len(B_M0)>0:
        #Set the resonance highlight initial state.
        
        #initial state of all resonances displayed
        for b in bplots:
            for z in b: z[0].set_visible(True)
        plots[1].set_title('Aligned '+antimode+' Peaks: '+str(len(bplots))+' Resonances')
        all_displayed = True
        
        #initial state of 1st resonance displayed
##        for b in bplots:
##            for z in b: z[0].set_visible(False)
##        for z in bplots[B_displayed]: z[0].set_visible(True)
##        plots[1].set_title('Aligned '+antimode+' Peaks: Resonance '+str(B_displayed+1)+'/'+str(len(bplots)))
##        all_displayed = False
        
        #layout & show
        plt.tight_layout(pad=1)
        fig.canvas.draw()
        #plt.show()
    #Else print the message that there isn't anything to graph.
    else:
        if len(A_M0)>0:
            print("  There are peaks in listA.")
        if len(B_M0)>0:
            print("  There are peaks in listB.")
        print("  There are no peaks to graph with current settings.\n  Please try again with different settings.")

def display_graph():
    fig.set_figheight(3.5)
    fig.set_figwidth(10)
    plt.show()
    #pass

def run_option_special(modality):#, parameter):#parameter will be generally considered to be a tuple of sorts, size and behavior determined by modality
    global dC_nca, dN_nca, dC_nco, dN_nco, p0, verbose
    #Decouple from standard graphing routine
    verbose = False
    p1 = p0+()
    storage = ( p1, dC_nca*1.0, dN_nca*1.0, dC_nco*1.0, dN_nco*1.0 )

    #run special routine
    denominator = 100
    if modality==0:
        c=40
        n=220
        p0 = [120.2,58.3,42.4]
        dC_nca = c/denominator
        dN_nca = n/denominator
        dC_nco = c/denominator
        dN_nco = n/denominator
        graph()
        print("graph complete")
        if c%10==0: strc = str(c/denominator)+'0'
        else: strc = str(c/denominator)
        if n%10==0: strn = str(n/denominator)+'0'
        else: strn = str(n/denominator)
        plt.savefig('plotsoutput/plot_c'+strc+'_n'+strn+'.png')
        plt.close()
    elif modality==1:#save array of plots at various tolerance values.  Only works if plt.show() in graph is disabled.
        p0 = [120.1, 55, 18.2]
        for c in range(10, 50, 10):#in hundredths of a ppm
            for n in range(20, 250, 50):#in hundredths of a ppm
                dC_nca = c/denominator
                dN_nca = n/denominator
                dC_nco = c/denominator
                dN_nco = n/denominator
                graph()
                print("graph complete")
                if c%10==0: strc = str(c/denominator)+'0'
                else: strc = str(c/denominator)
                if n%10==0: strn = str(n/denominator)+'0'
                else: strn = str(n/denominator)
                plt.savefig('plotsoutput/plot_c'+strc+'_n'+strn+'.png')
                plt.close()
    elif modality==2:
        p0list = [
            [1,120,55.1,18.1],
            [2,120,55.7,32.6],
            [3,120.1,55,18.2],
            [4,119,60.5,34.7],
            [25,122.8,54.9,43]
            ]
        for p in range(20, 20):#len(p0list)):
            p0 = p0list[p][1:]
            for c in range(10, 50, 10):#in hundredths of a ppm
                for n in range(20, 250, 50):#in hundredths of a ppm
                    dC_nca = c/denominator
                    dN_nca = n/denominator
                    dC_nco = c/denominator
                    dN_nco = n/denominator
                    graph()
                    print("graph complete")
                    if c%10==0: strc = str(c/denominator)+'0'
                    else: strc = str(c/denominator)
                    if n%10==0: strn = str(n/denominator)+'0'
                    else: strn = str(n/denominator)
                    plt.savefig('plotsoutput/'+str(p0list[p][0])+'_plot_c'+strc+'_n'+strn+'.png')
                    plt.close()
    elif modality==3:#print graph as an eps file
        graph()
        plt.savefig('plotsoutput/plot_c.ps')
        plt.show()
        #plt.close()

    #reinstate standard graphing routine values
    p0, dC_nca, dN_nca, dC_nco, dN_nco = storage[0], storage[1]*1.0,  storage[2]*1.0,  storage[3]*1.0,  storage[4]*1.0
    verbose = True
    
###############################################################################

load_configuration()
load_peaklists()
run_text_gui()
run_options_menu()
save_configuration()

